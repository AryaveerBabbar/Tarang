// Shared cart + wishlist logic. Uses localStorage, so it persists per-browser
// without needing a backend. Included on every page before main.js.

const CART_KEY = "tarang_cart";      // { [productId]: qty }
const WISHLIST_KEY = "tarang_wishlist"; // [productId, ...]

function getCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || {}; }
  catch { return {}; }
}
function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateHeaderCounts();
}
function addToCart(id, qty = 1) {
  const cart = getCart();
  cart[id] = (cart[id] || 0) + qty;
  saveCart(cart);
}
function setQty(id, qty) {
  const cart = getCart();
  if (qty <= 0) delete cart[id];
  else cart[id] = qty;
  saveCart(cart);
}
function removeFromCart(id) {
  const cart = getCart();
  delete cart[id];
  saveCart(cart);
}
function clearCart() { saveCart({}); }

function cartLineItems() {
  const cart = getCart();
  return Object.entries(cart).map(([id, qty]) => {
    const product = PRODUCTS.find(p => p.id === id);
    return product ? { ...product, qty } : null;
  }).filter(Boolean);
}
function cartCount() {
  return Object.values(getCart()).reduce((a, b) => a + b, 0);
}
function cartTotal() {
  return cartLineItems().reduce((sum, item) => sum + item.price * item.qty, 0);
}

function getWishlist() {
  try { return JSON.parse(localStorage.getItem(WISHLIST_KEY)) || []; }
  catch { return []; }
}
function saveWishlist(list) {
  localStorage.setItem(WISHLIST_KEY, JSON.stringify(list));
  updateHeaderCounts();
}
function isWishlisted(id) { return getWishlist().includes(id); }
function toggleWishlist(id) {
  let list = getWishlist();
  if (list.includes(id)) list = list.filter(x => x !== id);
  else list.push(id);
  saveWishlist(list);
  return list.includes(id);
}
function wishlistItems() {
  return getWishlist().map(id => PRODUCTS.find(p => p.id === id)).filter(Boolean);
}

function updateHeaderCounts() {
  document.querySelectorAll("[data-cart-count]").forEach(el => {
    const n = cartCount();
    el.textContent = n;
    el.style.display = n > 0 ? "inline-flex" : "none";
  });
  document.querySelectorAll("[data-wishlist-count]").forEach(el => {
    const n = getWishlist().length;
    el.textContent = n;
    el.style.display = n > 0 ? "inline-flex" : "none";
  });
}

// Decorative bead-ring art used in place of photography. Deterministic per
// product so the same piece always renders the same way.
function braceletArt(product, size = 200) {
  const [c1, c2, c3] = product.colors;
  const beads = 14;
  const r = size * 0.32;
  const cx = size / 2, cy = size / 2;
  let dots = "";
  for (let i = 0; i < beads; i++) {
    const angle = (i / beads) * Math.PI * 2;
    const x = cx + r * Math.cos(angle);
    const y = cy + r * Math.sin(angle);
    const color = [c1, c2, c3][i % 3];
    const br = size * (i % 5 === 0 ? 0.055 : 0.04);
    dots += `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${br.toFixed(1)}" fill="${color}" />`;
  }
  return `<svg viewBox="0 0 ${size} ${size}" role="img" aria-label="${product.name}">
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${c1}" stroke-width="1" stroke-opacity="0.25"/>
    ${dots}
  </svg>`;
}

// Shared product card markup + click handling, used on home, shop, and
// anywhere else a grid of products appears.
function cardHTML(p) {
  const wished = isWishlisted(p.id);
  return `
    <div class="card">
      <div class="card-art">
        <a href="product.html?id=${p.id}">${braceletArt(p, 200)}</a>
        <button class="wish-toggle ${wished ? "active" : ""}" data-wish="${p.id}" aria-label="Toggle wishlist">
          <svg viewBox="0 0 24 24"><path d="M12 21s-7-4.35-9.5-8.5C.5 8.5 2.5 5 6 5c2 0 3.5 1 4 2.5C10.5 6 12 5 14 5c3.5 0 5.5 3.5 3.5 7.5C19 16.65 12 21 12 21z"/></svg>
        </button>
      </div>
      <div class="card-body">
        <div class="card-cat">${p.category}</div>
        <a href="product.html?id=${p.id}" class="card-name">${p.name}</a>
        <div class="card-blurb">${p.blurb}</div>
        <div class="card-foot">
          <span class="price">${formatINR(p.price)}</span>
          <button class="card-add" data-add="${p.id}">Add to cart</button>
        </div>
      </div>
    </div>`;
}

function flashButton(btn) {
  const original = btn.textContent;
  btn.textContent = "Added ✓";
  setTimeout(() => btn.textContent = original, 900);
}

document.addEventListener("click", (e) => {
  const addBtn = e.target.closest("[data-add]");
  if (addBtn) { addToCart(addBtn.getAttribute("data-add"), 1); flashButton(addBtn); }
  const wishBtn = e.target.closest("[data-wish]");
  if (wishBtn) {
    const active = toggleWishlist(wishBtn.getAttribute("data-wish"));
    wishBtn.classList.toggle("active", active);
  }
});

document.addEventListener("DOMContentLoaded", updateHeaderCounts);
