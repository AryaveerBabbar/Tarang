// Vercel serverless function: POST /api/create-order
// Creates a Razorpay order server-side (so the secret key never reaches the
// browser) and stashes the shipping address + item list in the order's
// `notes` field so you can see full order details in the Razorpay dashboard
// without needing a separate database.
const Razorpay = require("razorpay");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  try {
    const { amount, items, shipping_info } = req.body || {};

    if (!amount || amount <= 0) {
      res.status(400).json({ error: "Invalid amount" });
      return;
    }
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
      res.status(500).json({ error: "Razorpay keys are not configured on the server" });
      return;
    }

    const instance = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });

    const itemsSummary = (items || [])
      .map((i) => `${i.name} x${i.qty} (₹${i.price})`)
      .join("; ")
      .slice(0, 500); // Razorpay note values are capped at 500 chars

    const order = await instance.orders.create({
      amount: Math.round(Number(amount) * 100), // rupees -> paise
      currency: "INR",
      receipt: "tarang_" + Date.now(),
      notes: {
        customer_name: shipping_info?.name || "",
        phone: shipping_info?.phone || "",
        email: shipping_info?.email || "",
        address: `${shipping_info?.address || ""}, ${shipping_info?.city || ""}, ${shipping_info?.state || ""} ${shipping_info?.pincode || ""}`,
        items: itemsSummary,
      },
    });

    res.status(200).json({
      id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: process.env.RAZORPAY_KEY_ID, // public key, safe to expose
    });
  } catch (err) {
    console.error("create-order error:", err);
    res.status(500).json({ error: "Failed to create order" });
  }
};
