// Vercel serverless function: POST /api/verify-payment
// Verifies the HMAC signature Razorpay returns after a successful payment,
// so a customer's browser can't fake a "payment succeeded" message.
const crypto = require("crypto");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {};
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      res.status(400).json({ verified: false, error: "Missing payment fields" });
      return;
    }

    const expected = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(razorpay_order_id + "|" + razorpay_payment_id)
      .digest("hex");

    const verified = expected === razorpay_signature;
    res.status(200).json({ verified });
  } catch (err) {
    console.error("verify-payment error:", err);
    res.status(500).json({ verified: false, error: "Verification failed" });
  }
};
